#!/bin/sh

# Clinton Cario 
#  03/23/2017 -- Initial version

for f in *.txt
do
	awk 'BEGIN  { FS="\t"; OFS="\t";process=FILENAME;} 
				{
						gsub(/[0-9]*\.txt/,"",FILENAME);
						split($1,a,"|");split(a[2],b,"="); 
						if (match(b[2], /ENSG.*/)) {next;}
						print "HGNC:"b[2], FILENAME 
				}' ${f}
done